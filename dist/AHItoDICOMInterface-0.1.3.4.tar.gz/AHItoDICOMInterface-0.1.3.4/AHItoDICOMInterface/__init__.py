"""
AHItoDICOMInterface.

A package to simply export DICOM dataset in memory or on the file system..
"""

__version__ = "0.1.3.4"
__author__ = 'JP Leger'
__credits__ = ''